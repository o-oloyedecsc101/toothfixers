export class CreatePatientDto {
    clinicDate : string;
    natureOfAilment : string;
    medicinePrescribed : string;
    prodecureUnderTaken : string;
    dateOfNextAppointment : string;

}
