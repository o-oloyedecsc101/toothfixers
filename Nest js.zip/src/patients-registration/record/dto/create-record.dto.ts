export class CreateRecordDto {
    firstName: string;
    surName: string;
    middleName?: string;
    dateOfBirth: string;
    homeAddress: string;
    dateOfRegistration: string;
    _matriculationNumber: boolean;
}



